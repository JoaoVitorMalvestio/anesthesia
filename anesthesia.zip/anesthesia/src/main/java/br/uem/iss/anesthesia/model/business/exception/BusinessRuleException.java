package br.uem.iss.anesthesia.model.business.exception;

public class BusinessRuleException extends Exception {

    public BusinessRuleException(String message) {
        super(message);
    }
}
